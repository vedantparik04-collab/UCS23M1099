import React, { useState } from "react";

function Message(props) {
  return <h2>Hello, {props.name}!</h2>;
}

function App() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <h1>React Example</h1>
      <Message name="Saee" />
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>Click Me</button>
    </div>
  );
}

export default App;
